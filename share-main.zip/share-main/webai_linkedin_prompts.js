People Summary - Give a short summary of this person
People interests - What topics is he/she posting about
Key Topics - What are the key topics and insights
Topic summary - Give a bulleted abstract for this post
Key Takeaways - Summarize with key take aways and list 5 follow up questions.
2 min read - Summarize for 2min read.
Key Terms - List the key terms and explain them
Key questions - List the questions this article is answering, along with answers (qoutes from the article)
Group highlights - What are the highlights of today’s posts
Group trends - What are the trending topics
Group links - Which sources are people sharing, list all the links
Jobs summary - Give a high level summary of the job
Linkedin post - Create a linkedin post highlighting the key takeaways from this.
Spanish - Translate into spanish
Custom - Create your own custom prompt
