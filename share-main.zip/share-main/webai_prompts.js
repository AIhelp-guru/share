Show Key Takeaways - Summarize with key take aways and list 5 follow up questions.
Make it 2 min read - Summarize for 2min read.
Make it 5 min read - Rewrite for a 5min read.
Create slides - Summarize this into slides with bulleted text.
Create FAQ - Create a FAQ based on this.
List Key Terms - List the key terms and explain them
List Key questions - List the questions this article is answering, along with answers (qoutes from the article)
Make it Easy - Create a version of this document using plain understandable language.
Create Linkedin post - Create a linkedin post highlighting the key takeaways from this.
Translate Spanish - Translate into spanish
Create Custom - Create your own custom prompt
